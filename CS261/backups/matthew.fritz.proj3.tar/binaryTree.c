#include "binaryTree.h"
#include <stdio.h>
#include <stdlib.h>

void insert(Node **currentPtr, int val) {
  Node * current = *currentPtr;

  if(current == NULL) {
    *currentPtr = malloc(sizeof(Node));
    current = *currentPtr;

    if( current != NULL ) {
      current->value = val;
      current->left = NULL;
      current->right = NULL;
    }
  } else if (val <= current->value) {
      insert(&(current->left), val);
  } else {
      insert(&(current->right), val);
  }
}

void search(Node *current, int val) {
  if(current == NULL) {
    printf("%d is missing\n", val);
    return;
  }
  if( val == current->value ) {
    printf("%d is present\n", val);
  } else if ( val < current->value ) {
    search(current->left, val);
  } else {
    search(current->right, val);
  }
}

void deleteVal(Node **currentPtr, int val) {
  if(*currentPtr == NULL) {
    return;
  }

  if( val == (*currentPtr)->value ) {
    if( ((*currentPtr)->left == NULL) && ((*currentPtr)->right == NULL) ) {
      free(*currentPtr);
      *currentPtr = NULL;
    } else if( (*currentPtr)->left == NULL ) {
      if( (*currentPtr)->right->left == NULL ) {
        Node * nodeToDelete = (*currentPtr)->right;
        (*currentPtr)->value = nodeToDelete->value;
        (*currentPtr)->right = nodeToDelete->right;
        free(nodeToDelete);
      } else {
        // Find the left most node in the right tree
        Node * parent = (*currentPtr)->right;
        Node * nodeToDelete;
        while( parent->left->left != NULL ) {
          parent = parent->left;
        }
        nodeToDelete = parent->left;
        (*currentPtr)->value = nodeToDelete->value;
        parent->left = nodeToDelete->right;
        free( nodeToDelete );
      }
    } else {
      if( (*currentPtr)->left->right == NULL ) {
        Node * nodeToDelete = (*currentPtr)->left;
        (*currentPtr)->value = nodeToDelete->value;
        (*currentPtr)->left = nodeToDelete->left;
        free(nodeToDelete);
      } else {
        // Find the right most node in the left tree
        Node * parent = (*currentPtr)->left;
        Node * nodeToDelete;
        while( parent->right->right != NULL ) {
          parent = parent->right;
        }
        nodeToDelete = parent->right;
        (*currentPtr)->value = nodeToDelete->value;
        parent->right = nodeToDelete->left;
        free( nodeToDelete );
      }
    }
  } else if ( val < (*currentPtr)->value ) {
    deleteVal(&((*currentPtr)->left), val);
  } else {
    deleteVal(&((*currentPtr)->right), val);
  }
}

void empty(Node **currentPtr) {
  if(*currentPtr == NULL) {
    return;
  }
  empty(&((*currentPtr)->left));
  empty(&((*currentPtr)->right));
  free(*currentPtr);
  *currentPtr = NULL;
}

void preOrder(Node *current) {
  if(current == NULL) {
    return;
  }
  printf("%d\n",current->value);
  preOrder(current->left);
  preOrder(current->right);
}

void inOrder(Node *current) {
  if(current == NULL) {
    return;
  }
  inOrder(current->left);
  printf("%d\n",current->value);
  inOrder(current->right);
}

void postOrder(Node *current) {
  if(current == NULL) {
    return;
  }
  postOrder(current->left);
  postOrder(current->right);
  printf("%d\n",current->value);
}
