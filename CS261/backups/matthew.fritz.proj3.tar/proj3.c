#include <stdio.h>
#include <stdlib.h>
#include "binaryTree.h"

int main() {
  Node *current = NULL;
  int numFound;
  int n;
  int keepGoing = 1;
  char buf[255];

  while( keepGoing ) {
    numFound = scanf("%s", &(buf[0]));
    if( numFound < 1 )
      continue;

    switch(buf[0]) {
      case 'i':
        numFound = scanf("%d", &n);
        if( numFound < 1 ) {
          scanf("%s", &(buf[0]));
          continue;
        }

        insert(&current, n);
        break;

      case 'd':
        numFound = scanf("%d", &n);
        if( numFound < 1 ) {
          scanf("%s", &(buf[0]));
          continue;
        }

        deleteVal( &current, n );
        break;

      case 's':
        numFound = scanf("%d", &n);
        if( numFound < 1 ) {
          scanf("%s", &(buf[0]));
          continue;
        }

        search(current, n);
        break;

      case 'e':
        empty(&current);
        break;

      case 't':
        numFound = scanf("%s", &buf[0]);
        if( numFound < 1 )
          continue;

        switch(buf[0]) {
          case 'i':
            inOrder(current);
            break;

          case 'l':
            preOrder(current);
            break;

          case 'r':
            postOrder(current);
            break;

          default:
            break;
        }
        break;

      case 'q':
        keepGoing = 0;
        break;

      default:
        break;
    }


  }

  empty(&current);
}
