#ifndef SFTP_H
#define SFTP_H
// Common header between server/client

#define MY_PORT_NUMBER 49999

#endif

