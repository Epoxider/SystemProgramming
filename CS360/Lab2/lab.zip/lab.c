#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>

int getAllStdin(char** buf) {
    printf("Reading in Stdin...\n");
    *buf = (char*)malloc(1000000);
    int bytes_read = read(0, *buf, 1000000);
    printf("Read %d bytes \n", bytes_read);
    (*buf)[bytes_read] = 0;
    return bytes_read;
}


int main(int argc, char* argv[]) {
    int rd, wd; //read & write descriptors
    char c;
    char str;
    int position;
    char * buf = NULL;
    
    if(argc < 2) {
        int length = getAllStdin(&buf);
        for (int i = length; i >= 0; i--) {
            write(1,&(buf[i]),1);
        }
    }
    else 
    {
        rd = open(argv[1], O_RDONLY);
        assert(rd > 0);
        position = lseek(rd, 0, SEEK_END);
        while(position >= 0 ) {
            read(rd,&c,1);
            write(1,&c,1);
            position = lseek(rd, -2, SEEK_CUR);
        }
    }
    close(rd);
    return 0;
}
    
