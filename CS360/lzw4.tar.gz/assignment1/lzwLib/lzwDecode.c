#include <sequence.h>
#include <bitStream.h>
#include <lzw.h>

bool lzwDecode(unsigned int bits, unsigned int maxBits,
               int  (*readFunc )(void* context),
               void (*writeFunc)(unsigned char c, void* context),
               void* context) {
    // 1: Table T is a table of Sequences, indexed by an integer code. The table
    //        must be large enough to hold as many codes as are permitted by the
    //        maximum code bit width. Initialize table T with entries 0 through 255
    //        with each holding a single character Sequence, one entry for each
    //        character 0 through 255, respectively.
    // 2: previousCode ← first code read from input
    // 3: while there are more codes to be read do
    // 4: currentCode ← next code from input
    // 5: if currentCode ∈ T then
    // 6: C ← first character of T[currentCode]
    // 7: else
    // 8: C ← first character of T[previousCode]
    // 9: if T is not full then
    // 10: W ← new sequence using T[previousCode] appended with C
    // 11: add W at next index in T
    // 12: output Sequence T[currentCode]
    // 13: previousCode ← currentCode
    return true;
}
