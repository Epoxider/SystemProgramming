#include <stdlib.h>
#include <sequence.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

unsigned int computeHash(unsigned char *str, unsigned int hashSize)
{
    unsigned long hash = 5381;
    int c;

    while ( (c = (int)(*str++)) ) { 
        hash = ((hash << 5) + hash) + c; /* hash * 33 + c */
    }
    hash %= hashSize;

    return hash;
}

Sequence* newSequence(unsigned char firstByte, unsigned int hashSize) {
    Sequence * s = (Sequence *)malloc( sizeof(Sequence) );
    assert( s != NULL );

    s->str = (unsigned char *)malloc( 2 * sizeof(char) );
    assert( s->str != NULL );

    s->str[0] = firstByte;
    s->str[1] = 0;

    s->hashValue = computeHash( s->str, hashSize );
    s->hashSize = hashSize;

    return s;
}

void deleteSequence(Sequence* sequence) {
    assert( sequence != NULL );
    assert( sequence->str != NULL );

    if( sequence != NULL ) {
        if( sequence->str != NULL ) {
            free(sequence->str);
        }
        free( sequence );
    }
}

Sequence* copySequenceAppend(Sequence* sequence, unsigned char addByte, unsigned int hashSize) {
    Sequence * s = NULL;
    int newLength = -1;

    assert( sequence != NULL );
    assert( sequence->str != NULL );

    s = (Sequence *)malloc( sizeof(Sequence) );
    assert( s != NULL );

    newLength = strlen((char *)sequence->str) + 1;
    s->str = (unsigned char *)malloc( (newLength + 1) * sizeof(char) );
    assert( s->str != NULL );

    strcpy( (char *)s->str, (char *)sequence->str );
    s->str[newLength - 1] = addByte; // This will replace the null terminator
    s->str[newLength] = 0;

    s->hashValue = computeHash( s->str, hashSize );
    s->hashSize = hashSize;

    return s;
}

void outputSequence(Sequence* s,
                    void (*writeFunc)(unsigned char c, void* context), void* context) {
    assert( s != NULL );
    assert( s->str != NULL );

    // Write each character to the output write function
    for( int i = 0; i < strlen((char *)(s->str)); i++ ) {
        (*writeFunc)( s->str[i], context );
    }
}

bool identicalSequences(Sequence* a, Sequence* b) {
    int length = -1;
    if( (a == NULL) || (a->str == NULL) || (b == NULL) || (b->str == NULL) ) {
        //printf("\n\nidenticalSequences: We had a NULL ptr\n");
        return false;
    }
    length = strlen((char *)a->str);
    if( (length != strlen((char *)(b->str))) || (a->hashSize != b->hashSize) ) {
        //printf("\n\nidenticalSequences: Lengths don't match\n");
        return false;
    }

    for( int i = 0; i < length; i++ ) {
        if( a->str[i] != b->str[i] ) {
            //printf("\n\nidenticalSequences: Mismatch at index %d, %c != %c\n", i, a->str[i], b->str[i] );
            return false;
        }
    }

    return true;
}
